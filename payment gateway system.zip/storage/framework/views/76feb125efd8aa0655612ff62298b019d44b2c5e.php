<?php $__env->startSection('title','Customer registration'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('errors.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card-header mt-5">
            <i class="fas fa-table"></i>
            My Customers</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Customername</th>
                        <th>Address</th>
                        <th>Email</th>
                        <th>Joining Date</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th>ID</th>
                        <th>Customername</th>
                        <th>Address</th>
                        <th>Email</th>
                        <th>Joining Date</th>
                    </tr>
                    </tfoot>
                    <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($customer->id); ?></td>
                            <td><?php echo e($customer->customername); ?></td>
                            <td><?php echo e($customer->address); ?></td>
                            <td><?php echo e($customer->email); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($customer->created_at)->format('d-m-Y')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card card-register mx-auto mt-5">
            <div class="card-header">Customer Account</div>
            <div class="card-body">
                <form action="<?php echo e(route('customer.register')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <div class="form-label-group">
                            <input type="text" name="customername" id="inputName" class="form-control" placeholder="Customer Name" required="required">
                            <label for="inputName">Customer Name</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-label-group">
                            <input type="text" name="address" id="inputAddress" class="form-control" placeholder="Address" required="required">
                            <label for="inputAddress">Address</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-label-group">
                            <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address" required="required">
                            <label for="inputEmail">Email address</label>
                        </div>
                    </div>
                    <input class="btn btn-primary btn-block" type="submit" name="submit" value="Save" >
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Assignment\paymentGateWay\resources\views/customer/CreateCustomer.blade.php ENDPATH**/ ?>