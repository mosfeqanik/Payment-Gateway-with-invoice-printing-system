<?php $__env->startSection('title','InvoiceDetails'); ?>
<?php $__env->startSection('content'); ?>
    <div class="table bg-white">
        <div class="contrainer">
            <div class="row">
                <div class="col-md-12">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                <tr>
                                    <th>Invoicee</th>
                                    <th>Ref</th>
                                    <th>Customer</th>
                                    <th>Email</th>
                                    <th>Customer order ref</th>
                                    <th>order Date</th>
                                    <th>Requied by</th>
                                    <th>delivery to</th>
                                    <th>order total</th>
                                    <th>Due </th>
                                    <th>Currency </th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th>Invoicee</th>
                                    <th>Ref</th>
                                    <th>Customer</th>
                                    <th>Email</th>
                                    <th>Customer order ref</th>
                                    <th>order Date</th>
                                    <th>Requied by</th>
                                    <th>delivery to</th>
                                    <th>order total</th>
                                    <th>Due </th>
                                    <th>Currency </th>
                                    <th>Actions</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                <tr>
                                    <td>Tiger Nixon</td>
                                    <td>System Architect</td>
                                    <td>Edinburgh</td>
                                    <td>61</td>
                                    <td>2011/04/25</td>
                                    <td>$320,800</td>
                                    <th>Action</th>
                                    <td>Edinburgh</td>
                                    <td>61</td>
                                    <td>2011/04/25</td>
                                    <td>$320,800</td>
                                    <th>Action</th>
                                </tr>
                                <tr>
                                    <td>Garrett Winters</td>
                                    <td>Accountant</td>
                                    <td>Tokyo</td>
                                    <td>63</td>
                                    <td>2011/07/25</td>
                                    <td>$170,750</td>
                                    <th>Action</th>
                                    <td>Tokyo</td>
                                    <td>63</td>
                                    <td>2011/07/25</td>
                                    <td>$170,750</td>
                                    <th>Action</th>
                                </tr>
                                <tr>
                                    <td>Ashton Cox</td>
                                    <td>Junior Technical Author</td>
                                    <td>San Francisco</td>
                                    <td>66</td>
                                    <td>2009/01/12</td>
                                    <td>$86,000</td>
                                    <th>Action</th>
                                    <td>Tokyo</td>
                                    <td>63</td>
                                    <td>2011/07/25</td>
                                    <td>$170,750</td>
                                    <th>Action</th>
                                </tr>
                                <tr>
                                    <td>Cedric Kelly</td>
                                    <td>Senior Javascript Developer</td>
                                    <td>Edinburgh</td>
                                    <td>22</td>
                                    <td>2012/03/29</td>
                                    <td>$433,060</td>
                                    <th>Action</th>
                                    <td>Tokyo</td>
                                    <td>63</td>
                                    <td>2011/07/25</td>
                                    <td>$170,750</td>
                                    <th>Action</th>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Assignment\paymentGateWay\resources\views/invoice/invoiceDetails.blade.php ENDPATH**/ ?>