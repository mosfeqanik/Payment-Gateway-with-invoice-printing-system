<?php $__env->startSection('title','InvoiceDetails'); ?>
<?php $__env->startSection('content'); ?>
    <div class="table bg-white">
        <div class="contrainer">
            <?php echo $__env->make('errors.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                <tr>
                                    <th>Invoice</th>
                                    <th>Ref</th>
                                    <th>Customer</th>
                                    <th>Email</th>
                                    <th>Customer order ref</th>
                                    <th>order Date</th>
                                    <th>Requied by</th>
                                    <th>delivery to</th>
                                    <th>order total</th>
                                    <th>Due </th>
                                    <th>Currency </th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th>Invoice</th>
                                    <th>Ref</th>
                                    <th>Customer</th>
                                    <th>Email</th>
                                    <th>Customer order ref</th>
                                    <th>order Date</th>
                                    <th>Requied by</th>
                                    <th>delivery to</th>
                                    <th>order total</th>
                                    <th>Due </th>
                                    <th>Currency </th>
                                    <th>Actions</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($invoice->id); ?></td>
                                        <td>Auto</td>
                                        <td><?php echo e($invoice->customername); ?></td>
                                        <td></td>
                                        <td></td>
                                        <td><?php echo e(Carbon\Carbon::parse($invoice->created_at)->format('d-m-Y')); ?></td>
                                        <td><?php echo e(Carbon\Carbon::parse( $invoice->updated_at)->addDays(3)->format('d-m-Y')); ?></td>
                                        <td><?php echo e($invoice->customername); ?></td>
                                        <td><?php echo e($invoice->total); ?></td>
                                        <td><?php echo e($invoice->total); ?></td>
                                        <td><?php echo e($invoice->currency); ?></td>
                                        <th><a href="<?php echo e(route('invoice.pdfexport',$invoice->id)); ?>" class="btn btn-outline-success btn-block">
                                                <i class="fas fa-print"></i>
                                            </a>
                                        </th>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Assignment\paymentGateWay\resources\views/Invoice/invoiceDetails.blade.php ENDPATH**/ ?>